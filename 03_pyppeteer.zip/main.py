# 使用ptppeteer 自动化

import asyncio
from pyppeteer import launch

async def mian():
    browser = await  launch()
    page = await browser.newPage()
    await page.goto('https://m.facebook.com/campaign/landing.php')
    await page.screenshot({'path': 'example.png'})
    dimensions = await page.evaluate('''() => {
            return {
                width: document.documentElement.clientWidth,
                height: document.documentElement.clientHeight,
                deviceScaleFactor: window.devicePixelRatio,
            }
        }''')

    print(dimensions)
    await page.browser.close()

asyncio.get_event_loop().run_until_complete(mian())