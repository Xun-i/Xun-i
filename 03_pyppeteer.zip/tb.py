import asyncio
import tkinter
import pyppeteer
from pyppeteer import launch

headers = {
    'user-agent':"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0",
    'cookie':'x-gpf-render-trace-id=2106f96716195991242405745e2204; XSRF-TOKEN=382d25b3-4694-40a0-8a46-170520dabcfb; _samesite_flag_=true; cookie2=1b8136db1a35674baecd3570769b8879; t=f5b4df41307d9b947efecc77b5525c93; _tb_token_=edddebb508ede; cna=vgwQGbL9YFMCAXUZUknqqOBU; xlly_s=1; sgcookie=E1009Kqj6t2t7wDCUgXep%2F%2BEc1pRm4YPHyFvIpG3Hqi8ZBCTCns%2BPt5OVU5bDZLyfCHaeZ31pzVfLAFwSqRve9m7LA%3D%3D; unb=2986103270; uc1=pas=0&existShop=true&cookie21=UtASsssmeWlNBv%2Fxp3RP&cookie15=WqG3DMC9VAQiUQ%3D%3D&cookie16=VT5L2FSpNgq6fDudInPRgavC%2BQ%3D%3D&cookie14=Uoe1i6rcgsM4fQ%3D%3D; uc3=lg2=W5iHLLyFOGW7aA%3D%3D&nk2=BJJmcb7Miw%3D%3D&id2=UUGq11NSJyvi2w%3D%3D&vt3=F8dCuwlGpWSEHCI6KlA%3D; csg=35603ecb; lgc=gd_%5Cu857E%5Cu6D8C; cookie17=UUGq11NSJyvi2w%3D%3D; dnk=gd_%5Cu857E%5Cu6D8C; skt=a89b7aeb220c6a94; existShop=MTYxOTU5OTEyMw%3D%3D; uc4=id4=0%40U2OdI4dFhVSYC2TqsH0n6g6sXgZk&nk4=0%40Bpa5MZWdulRBQNqSwyQxusij; tracknick=gd_%5Cu857E%5Cu6D8C; _cc_=VFC%2FuZ9ajQ%3D%3D; _l_g_=Ug%3D%3D; sg=%E6%B6%8C09; _nk_=gd_%5Cu857E%5Cu6D8C; cookie1=BxeCg24fzUeYWD2S7OittOWFvmlXTAIUVLrLvroABf8%3D; tfstk=cayGB__B15l61Vc3NOM_XbsnkVDGatvqr-yQL-kdEAoK3eaZbsqeTQ56XM0GmDAf.; l=eBNFLf07jXFAGCGjBO5Zlurza779oBdf6sPzaNbMiInca1u1gLEFANCC1GhezdtjgtfvAetPwN3oRRB4q3adgDot750J3Y1CxY9Hr; isg=BAAA8Or8dEoX3ghONYqBDhtI0Y7SieRTf1EcTXqWSJsg9YAfIpnZ4kyDCV01xZwr'
}
url = 'https://item.upload.taobao.com/router/publish.htm?spm=a1z09.1.favorite.d48.539b3606c9T55M'

print(pyppeteer.__chromium_revision__)
print(pyppeteer.executablePath())

def screen_size():
    tk = tkinter.Tk()
    width = tk.winfo_screenwidth()
    height = tk.winfo_screenheight()
    tk.quit()
    return {'width': width, 'height': height}

# 异步运行
async def crawl(url):
    browser = await launch(headless=False)
    page = await browser.newPage()
    await page.goto(url)
    title = await page.title()
    print(title)
    await browser.close()


async def main():
    # browser = await launch(headless=False, args=['--start-maximized'])  # 页面全屏
    # page = await browser.newPage()
    # await page.setViewport(screen_size())  # 内容全屏
    # await page.goto('https://m.facebook.com/campaign/landing.php')
    # input()
    # await browser.close()

    # 页面内容
    # browser = await launch(headless=False)
    # page = await browser.newPage()
    # url = 'https://www.baidu.com/'
    # await page.goto(url)
    # # content = await page.content()
    # content = await page.evaluate('document.body.textContent', force_expr=True)
    # print(content)
    # input()
    # await browser.close()

    # 异步运行
    # urls = [
    #         crawl('https://www.baidu.com/'),
    #         crawl('https://www.bing.com/')
    #     ]
    # await asyncio.wait(urls)

    start_parm = {
        "headless": False,
        "args": [
            '--disable-infobars',  # 关闭自动化提示框
            '--no-sandbox',  # 关闭沙盒模式
            '--start-maximized',  # 窗口最大化模式
        ],
    }
    browser = await launch(**start_parm)
    page = await browser.newPage()

    tk = tkinter.Tk()
    width = tk.winfo_screenwidth()
    height = tk.winfo_screenheight()
    tk.quit()

    print(f'设置窗口为：width：{width} height：{height}')

    # 设置网页 视图大小
    await page.setViewport(viewport={'width': width, 'height': height})
    await page.goto('http://www.nows.fun/')
    page_text = await page.content()
    print(page_text)
    await browser.close()


asyncio.get_event_loop().run_until_complete(main())